# Captain's Log — Bandit Wargame

---

## Level 5 → Level 6

**Objective:** Find the password in a file that is human-readable, 1033 bytes in size, and not executable.

**Command used:**
```bash
find ~/inhere -type f -size 1033c ! -executable
cat /home/bandit5/inhere/maybehere07/.file2
```

**Why it worked:** The `find` command with `-size 1033c` filtered all files by exact byte size, and `! -executable` excluded any executable files, leaving only the one file matching all conditions. The `cat` command then printed the password stored inside it.

---

## Level 7 → Level 8

**Objective:** Find the password stored in `data.txt` next to the word "millionth".

**Command used:**
```bash
grep "millionth" data.txt
```

**Why it worked:** `grep` searches through the file line by line and prints only the line containing the keyword "millionth", which had the password right next to it.

---

## Level 8 → Level 9

**Objective:** Find the only line that appears exactly once in `data.txt`.

**Command used:**
```bash
sort data.txt | uniq -u
```

**Why it worked:** `sort` arranged all lines alphabetically so identical lines were adjacent, and `uniq -u` then filtered and printed only the lines that appeared exactly once which was the password.

---

## Level 15 → Level 16

**Objective:** Submit the current level's password to port 30001 on localhost using SSL encryption to receive the next password.

**Note:** The password `8xCjnmgoKbGLhHFAZlGE5Tmu4M2tKJQo` was obtained in the previous level.

**Command used:**
```bash
echo "8xCjnmgoKbGLhHFAZlGE5Tmu4M2tKJQo" | openssl s_client -connect localhost:30001 -quiet
```

**Why it worked:** Port 30001 requires an SSL-encrypted connection, so plain `nc` (netcat) would not work. `openssl s_client` establishes an SSL handshake with the server, and piping the password via `echo` sends it through the encrypted channel, which the server responds to with the next level's password.

---

