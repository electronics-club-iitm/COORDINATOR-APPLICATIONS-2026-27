# Captain's Log : OverTheWire Bandit Solutions (levels : 5, 7, 8, 15)



## Level 5
### Commands used to find the password.

'''ssh bandit5@bandit.labs.overthewire.org -p 2220
   4oQYVPkxZOOEOO5pTW81FB8j8lxXGUQw
   ls
   cd inhere
   ls
   find . -readable -size 1033c -not -executable
   cat ./maybehere07/.file2'''
   
#### Brief Explanation
I used the -readable, -size, and -not -executable flags in the find command because it allowed me to filter out all the incorrect files,
and pinpoint the exact hidden file the level. Once I found it, I just used cat to read the password.



## Level 7
### Commands used to find the password

'''ssh bandit7@bandit.labs.overthewire.org -p 2220
   morbNTDkSW6jIlUc0ymOdMaLnOlFVAaj
   ls
   cat data.txt | grep millionth'''
   
#### Brief Explanation
I piped the output to grep because the data.txt file contained way too much text to search manually,
so I tried to isolate the single line containing the word "millionth".



## Level 8
### Commands used to find the password

'''ssh bandit8@bandit.labs.overthewire.org -p 2220
   dfwvzFQi4mU0wfNbFOe9RoWskMLg7eEc
   ls
   cat data.txt | sort | uniq -u'''
   
#### Brief Explanation
I piped the output to sort first because the uniq command only works to find duplicates if the identical lines are right next to each other. 
Then, I used the -u flag in uniq because it deletes all the repeated lines, leaving only the unique line that has the password.



## Level 15
### Commands used to find password

'''ssh bandit15@bandit.labs.overthewire.org -p 2220
   8xCjnmgoKbGLhHFAZlGE5Tmu4M2tKJQo
   pass=8xCjnmgoKbGLhHFAZlGE5Tmu4M2tKJQo
   openssl s_client -connect localhost:30001
   8xCjnmgoKbGLhHFAZlGE5Tmu4M2tKJQo'''

#### Brief Explanation
I used the openssl s_client command because standard network tools can't handle the SSL encryption required to connect to port 30001. 
This allowed me to create a secure connection, submit my current password, and get the new one back from the server.
