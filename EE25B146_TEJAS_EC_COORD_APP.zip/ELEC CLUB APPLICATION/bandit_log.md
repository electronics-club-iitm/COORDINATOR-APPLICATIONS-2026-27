Level5:
Command used:
'find . -type f -size 1033c ! -executable'
find is used for getting file by filename or by conditions. "." measn in current directory.
So type f stands for : search for file, not directory.
size is for storage of the file. c is for bytes.

! executable : not executable.





Level7:
Command used:
'grep "millionth" data.txt'

grep is used to get the line containing the word we put after grep. Since, the password is just after the word "millionth", we use grep to get the line itself. In that line only word after millionth is password.


Level8:
Command used:
'sort data.txt | uniq -u'
uniq can remove duplicate lines that are consequetive only. So, first we use sort to get all lines in alphabetical order and then use uniq -u to get only lines that never repeat.
uniq : for getting lines without their copies
uniq -u: for getting lines that never repeat at all.

Level 15:

Level15:
Command used:
'openssl s_client -connect localhost:30001'
then type password for the level, to get the password to next level

Level14, was just to send password to the port by tcp protocol, that can be done by
nc <ip address> <port number>
text

Now to transmit using ssl/tls encryption.

So, similar to nc even the commands -
openssl s_client acts like nc but with SSL encryption.
-connect <IP Adress>:<portnumber>

openssl s_client -connect localhost:30001
openssl s_client is transmitting tcp messages with ssl encryption. -connect : tells connect to the port number and
IP Address of the listener.

